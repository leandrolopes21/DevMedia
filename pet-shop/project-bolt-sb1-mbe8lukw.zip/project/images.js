// This file contains references to images we're using
export const dogImages = [
  'https://images.pexels.com/photos/58997/pexels-photo-58997.jpeg',
  'https://images.pexels.com/photos/6568500/pexels-photo-6568500.jpeg',
  'https://images.pexels.com/photos/6568537/pexels-photo-6568537.jpeg',
  'https://images.pexels.com/photos/7210754/pexels-photo-7210754.jpeg',
  'https://images.pexels.com/photos/7516509/pexels-photo-7516509.jpeg'
];

// Placeholder for brand logos (in a real project these would be actual logo URLs)
export const brandLogos = [
  'https://images.pexels.com/photos/7000001/brand1-placeholder.jpg',
  'https://images.pexels.com/photos/7000002/brand2-placeholder.jpg',
  'https://images.pexels.com/photos/7000003/brand3-placeholder.jpg',
  'https://images.pexels.com/photos/7000004/brand4-placeholder.jpg',
  'https://images.pexels.com/photos/7000005/brand5-placeholder.jpg',
  'https://images.pexels.com/photos/7000006/brand6-placeholder.jpg',
  'https://images.pexels.com/photos/7000007/brand7-placeholder.jpg',
  'https://images.pexels.com/photos/7000008/brand8-placeholder.jpg',
  'https://images.pexels.com/photos/7000009/brand9-placeholder.jpg',
  'https://images.pexels.com/photos/7000010/brand10-placeholder.jpg',
  'https://images.pexels.com/photos/7000011/brand11-placeholder.jpg',
  'https://images.pexels.com/photos/7000012/brand12-placeholder.jpg',
];