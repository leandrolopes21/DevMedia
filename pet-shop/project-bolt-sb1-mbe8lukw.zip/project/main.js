import './style.css'
import { dogImages, brandLogos } from './images.js'

// You can use this file to add any interactive functionality later if needed
document.addEventListener('DOMContentLoaded', () => {
  console.log('Pet Boutique website loaded successfully')
})